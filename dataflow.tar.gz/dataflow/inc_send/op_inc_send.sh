#!/usr/bin/env bash
# genderated by dataflow/tools/op_tpl.py

BINARY="inc_send"
INITOK="inc_send init ok"
WAITSTART="20"
WAITSTOP="10"
program="$(basename $0)"

function WARN() {
    echo "[31m$1[0m"
}

function INFO() {
    echo "[32m$1[0m"
}

function TRAC() {
    echo "$1"
}

function help() {
    INFO "usage: $1 [start | stop | restart]"
}

function start() {
    # 如果已经启动直接返回
    if [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -ne 0 ]]; then
        INFO "${BINARY} is already started."
        INFO "    $(ps aux | grep ${BINARY} | grep -v grep)"
        return 0
    fi

    # 执行启动命令
    INFO "try start ${BINARY}......"
    INFO "    CMD: [nohup ./bin/${BINARY} &]"
    nohup ./bin/${BINARY} &

    # 检查程序是否启动, waitstart时间后退出
    ((endTime = $(date +%s) + ${WAITSTART}))
    while [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -eq 0 && (($(date +%s) < ${endTime})) ]]; do
        ((timeLeft = ${endTime} - $(date +%s)))
        TRAC "    wait start. [${timeLeft}] seconds exit."
        sleep 1
    done
    if [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -eq 0 ]]; then
        WARN "start failed. no process [${BINARY}] found."
        return 1
    fi

    # 检查日志文件, 直到出现initok标志
    INFO "check initok....."
    while [[ $(grep "${INITOK}" log/${BINARY}.log | wc -l) -eq 0 && (($(date +%s) < ${endTime})) ]]; do
        ((timeLeft = ${endTime} - $(date +%s)))
        TRAC "    wait initok. [${timeLeft}] seconds exit."
        sleep 1
    done
    if [[ $(grep "${INITOK}" log/${BINARY}.log | wc -l) -eq 0 ]]; then
        WARN "check status failed. no [${INITOK}] in [log/${BINARY}.log]"
        return 1;
    fi

    # 检查日志文件, 如果出现任何fatal, 启动失败
    INFO "check fatal......"
    if [[ $(grep FATAL log/${BINARY}.log | wc -l) -ne 0 ]]; then
        WARN "check fatal failed. $(grep FATAL log/${BINARY}.log | wc -l) fatals found in [log/${BINARY}.log.wf]"
        return 1;
    fi

    # 启动成功
    INFO "Congratulations! start ${BINARY} success! Good Luck!"

    return 0;
}

function stop() {
    if [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -eq 0 ]]; then
        INFO "${BINARY} is already stoped."
        return 0
    fi

    # 发送kill信号
    INFO "try stop ${BINARY}......"
    INFO "    CMD: [killall ${BINARY}]"
    killall ${BINARY}

    # 等待程序退出
    ((endTime = $(date +%s) + ${WAITSTOP}))
    while [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -ne 0 && (($(date +%s) < ${endTime})) ]]; do
        ((timeLeft = ${endTime} - $(date +%s)))
        TRAC "    wait stop. [${timeLeft}] seconds exit."
        sleep 1
    done
    if [[ $(ps aux | grep ${BINARY} | grep -v grep | grep -v ${program} | wc -l) -ne 0 ]]; then
        WARN "stop failed. process [${BINARY}] is still exists."
        return 1
    fi

    # 停止成功
    INFO "Congratulations! stop ${BINARY} success! Good Luck!"
    return 0
}

function restart() {
    stop && start
}

case $1 in
    "start") start;;
    "stop") stop;;
    "restart") restart;;
    *) help $0;;
esac

